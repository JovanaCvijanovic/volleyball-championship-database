-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2025 at 02:55 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `odbojkasko_prvenstvo`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `najmanji_poeni` (IN `ime` VARCHAR(25), IN `prezime` VARCHAR(30))   BEGIN
SELECT `igrac`.`ime` as `Ime`, `igrac`.`prezime` as `Prezime`, `igrac`.`najmanje_poena_dato` as `Najmanji poeni`
FROM `igrac`
WHERE `igrac`.`najmanje_poena_dato` < (SELECT `igrac`.`najmanje_poena_dato` FROM `igrac` WHERE `igrac`.`ime`= ime AND `igrac`.`prezime`= prezime)
ORDER BY `igrac`.`najmanje_poena_dato` ASC;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `dvorana`
--

CREATE TABLE `dvorana` (
  `idDvor` smallint(5) UNSIGNED NOT NULL,
  `naziv_dvorane` varchar(40) NOT NULL,
  `kapacitet` int(10) UNSIGNED NOT NULL,
  `grad` varchar(20) NOT NULL,
  `drzava` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `dvorana`
--

INSERT INTO `dvorana` (`idDvor`, `naziv_dvorane`, `kapacitet`, `grad`, `drzava`) VALUES
(111, 'Paris La Defense Arena', 40000, 'Pariz', 'Francuska'),
(222, 'Palazzetto dello sport di Firenze', 7500, 'Firenca', 'Italija'),
(333, 'Stark Arena', 19300, 'Beograd', 'Srbija');

-- --------------------------------------------------------

--
-- Table structure for table `igra`
--

CREATE TABLE `igra` (
  `idIgraca` int(10) UNSIGNED NOT NULL,
  `idUtak` smallint(5) UNSIGNED NOT NULL,
  `as_poen` smallint(5) UNSIGNED NOT NULL,
  `blok_poen` smallint(5) UNSIGNED NOT NULL,
  `aut` tinyint(3) UNSIGNED NOT NULL,
  `servis_greska` tinyint(3) UNSIGNED NOT NULL,
  `duplikontakt_greska` tinyint(3) UNSIGNED NOT NULL,
  `pecanje_greska` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `igra`
--

INSERT INTO `igra` (`idIgraca`, `idUtak`, `as_poen`, `blok_poen`, `aut`, `servis_greska`, `duplikontakt_greska`, `pecanje_greska`) VALUES
(1, 2, 4, 4, 1, 1, 0, 0),
(2, 2, 1, 4, 2, 1, 0, 0),
(3, 2, 2, 2, 2, 3, 0, 0),
(4, 2, 0, 2, 0, 1, 0, 3),
(5, 2, 1, 1, 1, 1, 0, 0),
(6, 2, 2, 0, 0, 2, 0, 0),
(7, 2, 1, 0, 0, 1, 1, 2),
(8, 2, 1, 3, 3, 1, 0, 2),
(9, 2, 1, 4, 2, 0, 0, 3),
(10, 2, 3, 5, 1, 2, 0, 3),
(11, 2, 5, 2, 1, 0, 0, 2),
(12, 2, 3, 2, 2, 1, 0, 0),
(13, 1, 4, 3, 4, 2, 0, 5),
(14, 1, 4, 4, 3, 3, 0, 2),
(15, 1, 3, 3, 0, 1, 0, 2),
(16, 1, 2, 2, 1, 0, 0, 0),
(17, 1, 2, 2, 2, 0, 1, 1),
(18, 1, 2, 0, 0, 2, 0, 2),
(19, 1, 2, 3, 0, 0, 0, 0),
(20, 1, 3, 2, 0, 1, 1, 2),
(21, 1, 4, 0, 2, 0, 0, 1),
(22, 1, 3, 2, 0, 0, 0, 0),
(23, 1, 3, 3, 3, 2, 0, 0),
(24, 1, 3, 3, 0, 2, 0, 1),
(1, 3, 5, 4, 0, 0, 0, 0),
(2, 3, 2, 2, 2, 2, 0, 0),
(3, 3, 3, 1, 0, 0, 0, 2),
(4, 3, 2, 2, 0, 1, 0, 3),
(5, 3, 5, 2, 2, 3, 0, 0),
(6, 3, 2, 0, 1, 4, 0, 1),
(13, 3, 3, 3, 2, 3, 0, 0),
(14, 3, 2, 2, 2, 0, 0, 0),
(15, 3, 1, 3, 3, 0, 0, 1),
(16, 3, 2, 4, 3, 0, 0, 0),
(17, 3, 2, 0, 0, 2, 1, 0),
(18, 3, 2, 2, 5, 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `igrac`
--

CREATE TABLE `igrac` (
  `idIgraca` int(10) UNSIGNED NOT NULL,
  `ime` varchar(25) NOT NULL,
  `prezime` varchar(30) NOT NULL,
  `oznakaRep` varchar(10) NOT NULL,
  `pocetna_pozicija` varchar(15) NOT NULL,
  `najvise_poena_dato` smallint(5) UNSIGNED NOT NULL,
  `najmanje_poena_dato` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `igrac`
--

INSERT INTO `igrac` (`idIgraca`, `ime`, `prezime`, `oznakaRep`, `pocetna_pozicija`, `najvise_poena_dato`, `najmanje_poena_dato`) VALUES
(1, 'Maja', 'Ognjenovic', 'SRB', 'tehnicar', 31, 15),
(2, 'Maja', 'Aleksic', 'SRB', 'srednji bloker', 22, 6),
(3, 'Silvija', 'Popovic', 'SRB', 'libero', 17, 13),
(4, 'Bojana', 'Milenkovic', 'SRB', 'primac', 19, 12),
(5, 'Tijana', 'Boskovic', 'SRB', 'korektor', 28, 15),
(6, 'Bjanka', 'Busa', 'SRB', 'primac servisa', 18, 10),
(7, 'Marija', 'Tusevljak', 'MNE', 'primac servisa', 29, 11),
(8, 'Katarina', 'Budrak', 'MNE', 'srednji bloker', 20, 7),
(9, 'Tijana', 'Tvrdisic', 'MNE', 'tehnicar', 15, 5),
(10, 'Dijana', 'Vukovic', 'MNE', 'korektor', 23, 8),
(11, 'Lana', 'Labovic', 'MNE', 'libero', 16, 9),
(12, 'Mina', 'Dragovic', 'MNE', 'primac', 14, 4),
(13, 'Emma', 'Holzinger', 'AUT', 'korektor', 22, 13),
(14, 'Anna', 'Brandhofer', 'AUT', 'libero', 25, 7),
(15, 'Marie', 'Graf', 'AUT', 'srednji bloker', 11, 3),
(16, 'Emilia', 'Garibovic', 'AUT', 'primac', 18, 12),
(17, 'Laura', 'Mog', 'AUT', 'tehnicar', 16, 5),
(18, 'Johanna', 'Hintereger', 'AUT', 'primac servisa', 13, 4),
(19, 'Giulia', 'Bernardi', 'ITA', 'libero', 18, 7),
(20, 'Aurora', 'Del Cika', 'ITA', 'korektor', 15, 9),
(21, 'Alice', 'Trinaestic', 'ITA', 'primac servisa', 21, 11),
(22, 'Giorgia', 'Federconi', 'ITA', 'srednji bloker', 12, 4),
(23, 'Beatrice', 'Montali', 'ITA', 'primac', 13, 7),
(24, 'Andrea', 'Djani', 'ITA', 'tehnicar', 22, 8);

-- --------------------------------------------------------

--
-- Table structure for table `reprezentacija`
--

CREATE TABLE `reprezentacija` (
  `oznakaRep` varchar(10) NOT NULL,
  `naziv_rep` varchar(30) NOT NULL,
  `ime_prezime_trenera` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `reprezentacija`
--

INSERT INTO `reprezentacija` (`oznakaRep`, `naziv_rep`, `ime_prezime_trenera`) VALUES
('AUT', 'Austrija', 'Anna Gruber'),
('ITA', 'Italija', 'Ferdinando de Djordji'),
('MNE', 'Crna Gora', 'Tatjana Bokan'),
('SRB', 'Srbija', 'Igor Kolakov');

-- --------------------------------------------------------

--
-- Table structure for table `sudija`
--

CREATE TABLE `sudija` (
  `idSud` smallint(5) UNSIGNED NOT NULL,
  `ime_sudije` varchar(25) NOT NULL,
  `prezime_sudije` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `sudija`
--

INSERT INTO `sudija` (`idSud`, `ime_sudije`, `prezime_sudije`) VALUES
(1, 'Vital', 'Hejnen'),
(2, 'Daniel', 'Rab'),
(3, 'Jovana', 'Krunic');

-- --------------------------------------------------------

--
-- Table structure for table `utakmica`
--

CREATE TABLE `utakmica` (
  `idUtak` smallint(5) UNSIGNED NOT NULL,
  `datum` date NOT NULL,
  `vreme` time NOT NULL,
  `faza_takmicenja` varchar(25) NOT NULL,
  `ekipa1` varchar(10) NOT NULL,
  `ekipa2` varchar(10) NOT NULL,
  `set_ekipe1` tinyint(3) UNSIGNED NOT NULL,
  `set_ekipe2` tinyint(3) UNSIGNED NOT NULL,
  `idDvor` smallint(5) UNSIGNED NOT NULL,
  `idSud` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `utakmica`
--

INSERT INTO `utakmica` (`idUtak`, `datum`, `vreme`, `faza_takmicenja`, `ekipa1`, `ekipa2`, `set_ekipe1`, `set_ekipe2`, `idDvor`, `idSud`) VALUES
(1, '2022-09-20', '11:30:00', 'polufinale', 'AUT', 'ITA', 3, 1, 222, 2),
(2, '2022-09-21', '05:45:00', 'polufinale', 'SRB', 'MNE', 3, 2, 333, 3),
(3, '2022-09-25', '02:40:00', 'finale', 'AUT', 'SRB', 1, 3, 111, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dvorana`
--
ALTER TABLE `dvorana`
  ADD PRIMARY KEY (`idDvor`);

--
-- Indexes for table `igra`
--
ALTER TABLE `igra`
  ADD KEY `fkidIgracaigra` (`idIgraca`),
  ADD KEY `fkidUtakigra` (`idUtak`);

--
-- Indexes for table `igrac`
--
ALTER TABLE `igrac`
  ADD PRIMARY KEY (`idIgraca`),
  ADD KEY `fkoznakaRepigrac` (`oznakaRep`);

--
-- Indexes for table `reprezentacija`
--
ALTER TABLE `reprezentacija`
  ADD PRIMARY KEY (`oznakaRep`);

--
-- Indexes for table `sudija`
--
ALTER TABLE `sudija`
  ADD PRIMARY KEY (`idSud`);

--
-- Indexes for table `utakmica`
--
ALTER TABLE `utakmica`
  ADD PRIMARY KEY (`idUtak`),
  ADD KEY `fkidDvorutakmica` (`idDvor`),
  ADD KEY `fkidSudutakmica` (`idSud`),
  ADD KEY `fkekipa1utakmica` (`ekipa1`),
  ADD KEY `fkekipa2utakmica` (`ekipa2`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `igra`
--
ALTER TABLE `igra`
  ADD CONSTRAINT `igra_ibfk_1` FOREIGN KEY (`idIgraca`) REFERENCES `igrac` (`idIgraca`) ON UPDATE CASCADE,
  ADD CONSTRAINT `igra_ibfk_2` FOREIGN KEY (`idUtak`) REFERENCES `utakmica` (`idUtak`) ON UPDATE CASCADE;

--
-- Constraints for table `igrac`
--
ALTER TABLE `igrac`
  ADD CONSTRAINT `igrac_ibfk_1` FOREIGN KEY (`oznakaRep`) REFERENCES `reprezentacija` (`oznakaRep`) ON UPDATE CASCADE;

--
-- Constraints for table `utakmica`
--
ALTER TABLE `utakmica`
  ADD CONSTRAINT `utakmica_ibfk_1` FOREIGN KEY (`idDvor`) REFERENCES `dvorana` (`idDvor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `utakmica_ibfk_2` FOREIGN KEY (`idSud`) REFERENCES `sudija` (`idSud`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `utakmica_ibfk_3` FOREIGN KEY (`ekipa1`) REFERENCES `reprezentacija` (`oznakaRep`) ON UPDATE CASCADE,
  ADD CONSTRAINT `utakmica_ibfk_4` FOREIGN KEY (`ekipa2`) REFERENCES `reprezentacija` (`oznakaRep`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
